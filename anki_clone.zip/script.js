// Firebase Setup
import { db, storage, auth, collection, getDocs, addDoc, updateDoc, doc, query, where, ref, uploadBytes, getDownloadURL, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "./firebase.js";

let currentCard = null;

// Login Function
window.login = async function () {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    try {
        await signInWithEmailAndPassword(auth, email, password);
        alert("Logged in!");
        loadFlashcards();
    } catch (error) {
        alert(error.message);
    }
};

// Signup Function
window.signup = async function () {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    try {
        await createUserWithEmailAndPassword(auth, email, password);
        alert("Account created!");
        loadFlashcards();
    } catch (error) {
        alert(error.message);
    }
};

// Logout Function
window.logout = async function () {
    await signOut(auth);
    alert("Logged out!");
};

// Load Flashcards (Only Due)
async function loadFlashcards() {
    const today = new Date();
    const q = query(collection(db, "flashcards"), where("dueDate", "<=", today));
    const querySnapshot = await getDocs(q);

    const cards = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    if (cards.length > 0) {
        currentCard = cards[0];
        document.getElementById("card-text").innerText = currentCard.question;
        if (currentCard.imageUrl) {
            document.getElementById("card-image").src = currentCard.imageUrl;
            document.getElementById("card-image").style.display = "block";
        }
    } else {
        document.getElementById("card-text").innerText = "No cards due.";
    }

    document.getElementById("card-section").style.display = "block";
}

// Flip Card
document.getElementById("flashcard").addEventListener("click", () => {
    if (currentCard) {
        document.getElementById("card-text").innerText =
            document.getElementById("card-text").innerText === currentCard.question
                ? currentCard.answer
                : currentCard.question;
    }
});

// Add Flashcard
window.addCard = async function () {
    const question = document.getElementById("question").value;
    const answer = document.getElementById("answer").value;
    const image = document.getElementById("image-upload").files[0];

    let imageUrl = "";
    if (image) {
        const imageRef = ref(storage, `flashcards/${image.name}`);
        await uploadBytes(imageRef, image);
        imageUrl = await getDownloadURL(imageRef);
    }

    await addDoc(collection(db, "flashcards"), { question, answer, imageUrl, easeFactor: 2.5, interval: 1, repetitions: 0, dueDate: new Date() });
    alert("Card added!");
};